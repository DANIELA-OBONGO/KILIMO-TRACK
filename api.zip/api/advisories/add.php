<?php
// POST /api/advisories/add.php  — org posts an advisory

require_once __DIR__ . '/../cors.php';
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 'Method not allowed', [], 405);
}

$body = getBody();

$org_id        = (int)($body['org_id']        ?? 0);
$title         = trim($body['title']         ?? '');
$content       = trim($body['content']       ?? '');
$target_region = trim($body['target_region'] ?? '') ?: null;

if (!$org_id || !$title || !$content) {
    respond(false, 'org_id, title, and content are required', [], 422);
}

$db   = getDB();
$stmt = $db->prepare(
    "INSERT INTO advisories (org_id, title, content, target_region) VALUES (?, ?, ?, ?)"
);
$stmt->bind_param("isss", $org_id, $title, $content, $target_region);

if ($stmt->execute()) {
    respond(true, 'Advisory posted', ['id' => $db->insert_id], 201);
} else {
    respond(false, 'Insert failed: ' . $stmt->error, [], 500);
}
$stmt->close();
$db->close();
