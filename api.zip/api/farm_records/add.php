<?php
// POST /api/farm_records/add.php

require_once __DIR__ . '/../cors.php';
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 'Method not allowed', [], 405);
}

$body = getBody();

$farmer_id    = (int)($body['farmer_id']    ?? 0);
$crop_type    = trim($body['crop_type']    ?? '');
$season_type  = trim($body['season_type']  ?? '');
$planting_date = trim($body['planting_date'] ?? '');

if (!$farmer_id || !$crop_type || !$season_type || !$planting_date) {
    respond(false, 'farmer_id, crop_type, season_type, and planting_date are required', [], 422);
}

$valid_seasons = ['Long Rains', 'Short Rains', 'Dry Season', 'Irrigation'];
if (!in_array($season_type, $valid_seasons, true)) {
    respond(false, 'Invalid season_type', [], 422);
}

$harvest_date  = trim($body['harvest_date']  ?? '') ?: null;
$growth_stage  = trim($body['growth_stage']  ?? '') ?: null;
$acreage       = isset($body['acreage']) && is_numeric($body['acreage']) ? (float)$body['acreage'] : null;
$field_name    = trim($body['field_name']    ?? '') ?: null;
$notes         = trim($body['notes']         ?? '') ?: null;
$farm_photo    = handleUpload('farm_photo', 'farm_photos', ['image/jpeg','image/png','application/pdf']);

$db   = getDB();
$stmt = $db->prepare(
    "INSERT INTO farm_records (farmer_id, crop_type, season_type, planting_date, harvest_date, growth_stage, acreage, field_name, notes, farm_photo)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param(
    "isssssdsss",
    $farmer_id, $crop_type, $season_type, $planting_date, $harvest_date,
    $growth_stage, $acreage, $field_name, $notes, $farm_photo
);

if ($stmt->execute()) {
    respond(true, 'Farm record added', ['id' => $db->insert_id], 201);
} else {
    respond(false, 'Insert failed: ' . $stmt->error, [], 500);
}
$stmt->close();
$db->close();
