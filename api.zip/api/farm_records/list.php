<?php
// GET /api/farm_records/list.php?farmer_id=1

require_once __DIR__ . '/../cors.php';
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respond(false, 'Method not allowed', [], 405);
}

$farmer_id = (int)($_GET['farmer_id'] ?? 0);
if (!$farmer_id) {
    respond(false, 'farmer_id is required', [], 422);
}

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id, crop_type, season_type, planting_date, harvest_date, growth_stage, acreage, field_name, notes, farm_photo, created_at
     FROM farm_records WHERE farmer_id = ? ORDER BY created_at DESC"
);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$db->close();

respond(true, 'OK', ['records' => $rows, 'count' => count($rows)]);
