<?php
// GET /api/pest_logs/list.php?farmer_id=1

require_once __DIR__ . '/../cors.php';
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respond(false, 'Method not allowed', [], 405);
}

$farmer_id = (int)($_GET['farmer_id'] ?? 0);
if (!$farmer_id) {
    respond(false, 'farmer_id is required', [], 422);
}

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id, pest_name, field_name, severity, date_observed, treatment_applied, status, pest_image, notes, created_at
     FROM pest_logs WHERE farmer_id = ? ORDER BY date_observed DESC"
);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$db->close();

$active   = array_filter($rows, fn($r) => $r['status'] === 'Active');
$resolved = array_filter($rows, fn($r) => $r['status'] === 'Resolved');

respond(true, 'OK', [
    'records'        => $rows,
    'count'          => count($rows),
    'active_count'   => count($active),
    'resolved_count' => count($resolved),
]);
