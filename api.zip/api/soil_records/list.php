<?php
// GET /api/soil_records/list.php?farmer_id=1

require_once __DIR__ . '/../cors.php';
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respond(false, 'Method not allowed', [], 405);
}

$farmer_id = (int)($_GET['farmer_id'] ?? 0);
if (!$farmer_id) {
    respond(false, 'farmer_id is required', [], 422);
}

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id, field_name, soil_type, ph_level, moisture_level, test_date, recommendation, notes, created_at
     FROM soil_records WHERE farmer_id = ? ORDER BY test_date DESC"
);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Calculate average pH
$avg_ph = null;
if (count($rows) > 0) {
    $avg_ph = round(array_sum(array_column($rows, 'ph_level')) / count($rows), 2);
}

$db->close();
respond(true, 'OK', ['records' => $rows, 'count' => count($rows), 'average_ph' => $avg_ph]);
